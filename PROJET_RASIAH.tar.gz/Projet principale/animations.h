/*!\file animations.h
 *
 * \brief Votre espace de liberté : c'est ici que vous pouvez ajouter
 * vos fonctions de transition et d'animation avant de les faire
 * référencées dans le tableau _animations du fichier \ref window.c
 *
 * Des squelettes d'animations et de transitions sont fournis pour
 * comprendre le fonctionnement de la bibliothèque. En bonus des
 * exemples dont un fondu en GLSL.
 *
 * \author Farès BELHADJ, amsi@ai.univ-paris8.fr
 * \date May 05, 2014
 */
#ifndef _ANIMATIONS_H

#define _ANIMATIONS_H

#ifdef __cplusplus
extern "C" {
#endif

  extern void transition_fondu(void (* a0)(int), void (* a1)(int), Uint32 t, Uint32 et, int state);
  extern void animation_flash(int state);
  extern void animation_vide(int state);
  extern void animation_damier(int state);


//  extern void animation_base(int state);
  extern void animation_earth(int state);
extern void animation_earth2(int state);
extern void animation_earth3(int state);
extern void animation_earth4(int state);
extern void animation_earth5(int state);
extern void animation_earth6(int state);

extern void exemple_d_animation_05(int state);
extern void exemple_d_animation_06(int state);
extern void exemple_d_animation_07(int state);
extern void exemple_d_animation_08(int state);
extern void exemple_d_animation_09(int state);
extern void exemple_d_animation_10(int state);
extern void exemple_d_animation_11(int state);
extern void exemple_d_animation_12(int state);
extern void exemple_d_animation_13(int state);
  extern void animationsInit(void);
  /* Dans base.c */
  extern void base_init(void);
  extern void base_draw(void);
  /* Dans earth.c */
  extern void earth_init(void);
  extern void earth_draw(void);

	  /* Dans earth2.c */
  extern void earth2_init(void);
  extern void earth2_draw(void);


  /* Dans earth3.c */
  extern void earth3_init(void);
  extern void earth3_draw(void);
 /* Dans earth4.c */
  extern void earth4_init(void);
  extern void earth4_draw(void);

/* Dans earth5.c */
  extern void earth5_init(void);
  extern void earth5_draw(void);

/* Dans earth6.c */
  extern void earth6_init(void);
  extern void earth6_draw(void);




#ifdef __cplusplus
}
#endif

#endif
